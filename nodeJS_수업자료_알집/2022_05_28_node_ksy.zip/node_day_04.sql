create database myblog;
/*실제로 프로젝트 써볼 database*/

create database test;
use test;

create table mylog_user(
	user_idx bigint auto_increment primary key,
    user_id varchar(20) unique not null,
    user_pw varchar(20) not null
);

insert into mylog_user (user_id, user_pw) values ('123','123');
insert into mylog_user (user_id, user_pw) values ('123','123'); /*에러*/
insert into mylog_user (user_id, user_pw) values ('1234','1234');
insert into mylog_user (user_id, user_pw) values ('1235','1235');

select * from mylog_user;
select user_pw from mylog_user where user_id = '123';
update mylog_user set user_id = '456' where user_idx = 1;
delete from mylog_user where user_id = "456";

