const express = require("express");
const path = require("path");
const nm = require("nodemailer");
const morgan = require("morgan");
const fs = require("fs");
const multer = require("multer");

const app = express();
app.set("port", 3000);

//미들웨어 셋팅
app.use(
  morgan("dev"),
  express.static(path.join("/", __dirname, "public")),
  express.json(),
  express.urlencoded({ extended: false })
);

//폴더 생성
try {
  fs.readdirSync("uploads");
} catch (error) {
  console.log("uploads 폴더가 없어서 폴더를 생성합니다");
  fs.mkdirSync("uploads/");
}

//멀터 셋팅
const upload = multer({
  storage: multer.diskStorage({
    destination(req, file, done) {
      done(null, "uploads");
    },
    filename(req, file, done) {
      const ext = path.extname(file.originalname);
      done(null, path.basename(file.originalname, ext) + Date.now() + ext);
    },
  }),
  limits: { fileSize: 5 * 1024 * 1024 }, //5MB 1024bite = 1KB,
});

//view 화면
app.get("/", (req, res) => {
  res.sendFile(path.join(__dirname + "/_mulerMail.html"));
});

//메일 api
app.post("/mail", upload.single("image"), (req, res) => {
  try {
    console.log(req.file);
    fs.readFile("uploads/" + req.file.filename, (err, data) => {
      if (err) {
        console.log(err);
      } else {
        const frommail = req.body.frommail;
        const tomail = req.body.tomail;
        const title = req.body.title;
        const content = req.body.content;

        const transport = nm.createTransport({
          service: "gmail",
          auth: {
            user: "여러분들 구글 이메일",
            pass: "여러분들 구글 이메일 암호", // 2단계 인증 시 보안 탭의 앱 비밀번호 삽입
          },
          host: "smtp.mail.com",
          port: "587",
          // https://myaccount.google.com/lesssecureapps 보안 허용
        });

        const mailOption = {
          from: frommail,
          to: tomail,
          subject: title,
          text: content,
          attachments: [{ filename: req.file.originalname, content: data }],
        };

        try {
          transport.sendMail(mailOption, (err, info) => {
            if (err) {
              console.log(err);
            } else {
              console.log(info);
              res.send("Ok");
            }
            transport.close();
          });
        } catch (error) {
          console.log(error);
        }
      }
    });
  } catch (error) {
    console.loeg(error);
  }
});

app.listen(app.get("port"), () => {
  console.log(app.get("port"), "번으로 실행하고 있습니다");
});
