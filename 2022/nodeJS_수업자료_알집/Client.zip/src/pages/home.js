import React from "react";
import HomeMain from "../components/home/homeMain";
import Layout from "../_layout/layout";

const Home = () => {
  return (
    <Layout>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/login" element={<Login />} />
          <Route path="/sign" element={<Sign />} />
        </Routes>
    </Layout>

  );
};
export default Home;
