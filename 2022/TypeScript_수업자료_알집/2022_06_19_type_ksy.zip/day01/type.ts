let hello: string = "hello";
console.log(hello);

//js
const jsAdd = (num1, num2) => {
  return num1 + num2;
};

//ts
// 매개변수에 타입                          // 리턴에 타입 정해줌 (리턴이 생략되면 얘도 생략 가능)
const tsAdd = (num1: number, num2: number): number => {
  return num1 + num2;
};
