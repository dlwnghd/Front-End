type realdPrice = {
  price: number;
};

interface CarDriving {
  drivingStart(): realdPrice;
  drivingStop(): realdPrice;
} // 클래스의 설계도

// 접근제어자
// private ----- 외부 접근 불가능
// static  ----- 생성자를 만들지 않아도 접근 가능, Class 레벨
// protected ---- 외부 접근 불가능, 상속 받은 자식 클래스에서 사용 가능
// public ------- 기본타입 공개한다, 외부에서 접근이 가능
class Car implements CarDriving {
  private brand: string; // 이 클래스 범위에서만 접근이 가능
  color: string;
  price: number;

  drivingStart() {
    console.log("시운전이 시작되었습니다");
    return { price: this.price };
  }
  drivingStop() {
    console.log("시운전이 종료되었습니다");
    return { price: this.price };
  }

  private constructor(brand: string, color: string, price: number) {
    this.brand = brand;
    this.color = color;
    this.price = price;
  }

  private engineStart() {
    console.log(this.brand + " 시동 켜기");
  }
  private engineStop() {
    console.log(this.brand + " 시동 끄기");
  }

  enginTest() {
    this.engineStart();
    this.engineStop();
  }

  static makeCar(brand: string, color: string, price: number): Car {
    return new Car(brand, color, price);
  }
}

//const myCar = new Car("Ferrari", "red", 65000);
const myCar = Car.makeCar("Ferrari", "red", 65000);
myCar.enginTest();
console.log(myCar.drivingStart());
//myCar.brand = "SAMSUNG";
