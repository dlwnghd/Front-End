// 타입추론
// 타입을 추론해서 정해준겁니다

let text = "hello";

const printMSG = (message: string = "hello"): void => {
  console.log(message);
};

const addNumber = (a: number, b: number): number => {
  return a + b;
  // 수와 수를 더했으니 자동으로 리턴 값도 추론
};

const result: number = addNumber(1, 2);

// 가급적 타입 추론도 쓰시면 안됩니다
// 자기 마음대로 판단 => 지금은 간단한 로직, 실무에서 사용한다고 하면 여기에 얼마나 많이 타입이 인자로
// 전달될 수 있겠습니까

// 타입 추론도 가급적이면 사용하지 않고, 명확히 타입을 정해주는 것이 보다 훨씬 안정적이다
