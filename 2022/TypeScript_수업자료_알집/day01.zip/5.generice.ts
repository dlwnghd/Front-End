{
  /*
  const checkNull = (arg: number | null): number => {
    if (arg == null) {
      throw new Error("값이 비어있습니다");
    } else return arg;
  };

  const checkNullString = (arg: string | null): string => {
    if (arg == null) {
      throw new Error("값이 비어있습니다");
    } else return arg;
  };

  const result = checkNull(123);
  console.log(result); // 123

  const result2 = checkNull(null);
  console.log(result2); // 에러 => 값이 비어있습니다

  const result3 = checkNullString("123");
  console.log(result3); // "123"
  */

  const checkNull = (arg: any | null): any => {
    if (arg == null) {
      throw new Error("값이 비어있습니다");
    } else return arg;
  };

  const result = checkNull(123);
  const result2 = checkNull("123");

  //T
  function checkNullG<G>(arg: G | null): G {
    if (arg == null) {
      throw new Error("값이 비어있습니다");
    } else return arg;
  }

  const result3 = checkNullG(123);
  const result4 = checkNullG("123");

  console.log(typeof result3);
}
