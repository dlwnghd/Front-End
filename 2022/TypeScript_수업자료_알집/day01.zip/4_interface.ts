interface User {
  userId: number;
  name: string;
}

interface Post {
  postId: number;
  content: string;
  User: User;
}

interface Post {
  Comments: {
    User: User;
    content: string;
  };
}

// 인터페이스 중복 선언이 가능합니다.
// typeAlias 보다 확장성이 좋습니다. 클래스에도 적용이 가능하고, 중복 선언으로 인한 재사용 가능

// 일반적으로는 인터페이스와 클래스를 타입으로 많이 사용하고
// union이나 tuple을 사용할 때만 typeAlias를 사용합니다

const Post: Post = {
  postId: 1,
  content: "안녕하세요",
  User: {
    userId: 2,
    name: "김성용",
  },
  Comments: {
    User: {
      userId: 2,
      name: "김성용",
    },
    content: "안녕하세요",
  },
};

/*
------------------------------------

... ChatListType.ts

export interface Post {
  postId: number;
  content: string;
  User: User;
}

export interface Comment {
  postId: number;
  content: string;
  User: User;
}

-----------------------------------


import React, { FC } from "react"
import { Post } from "./ChatListType"

interface Props {
    post: Post;
    comment: Comment;
  }

  const ChatList: FC<Props> = ({ post, comment }) => {

    return (
        <div>
        </div>
    )
  }

  return ChatList;
-----------------------------------
*/
