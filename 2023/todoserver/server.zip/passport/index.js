import passport from 'passport';
import User from '../models/user/user.js';
import local from './local.js';
import jwt from './jwt.js';

export default () => {
  passport.serializeUser((user, done) => {
    done(null, user.id);
  });

  passport.deserializeUser(async (id, done) => {
    try {
      const user = await User.findOne({ where: { id } });
      done(null, user);
    } catch (err) {
      console.error(err);
      done(err);
    }
  });

  local();
  jwt();
};
